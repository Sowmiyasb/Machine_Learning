EXPLORE US BIKESHARE DATA

Three Major Cities
Chicago
New York
Washington

Datasets
All major city contains columns as listed below
Start Time
End Time
Trip Duration (in seconds)
Start Station
End Station
User Type (Subscriber or Customer)

Only Chicago and New york datasets contains column named Gender and Birth Year

Statisics computed to find below as mentioned in a project guidelines
#1 Popular times of travel 
#2 Popular stations and trip
#3 Trip duration
#4 User info

Resources I reffered to solve tasks are listed below

Usage of time strftime method()
https://www.tutorialspoint.com/python/time_strftime.htm

Usage of time strptime method()
https://www.tutorialspoint.com/python/time_strptime.htm

Usage of and operator in loc function
https://stackoverflow.com/questions/41691081/pandas-use-and-operator-in-loc-function

Usage of groupby function
https://www.tutorialspoint.com/python_pandas/python_pandas_groupby.htm

To understand the indexing of two dimensional list array
https://snakify.org/en/lessons/two_dimensional_lists_arrays/

Accessing characters in strings by index in Python
https://www.pythoncentral.io/cutting-and-slicing-strings-in-python/

I also reffered stackoverflow and python documentation to understand and clear errors
