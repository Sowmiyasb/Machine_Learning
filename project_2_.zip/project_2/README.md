P2-Test-a-Perceptual-Phenomenon:
===============================


This is the second project of the Udacity Data Analyst Nanodegree. 

Project Contents:
=================


1. This project contains an excel spreadsheet containing all the numerical data, frequency distributions, and calculation of mean, t-statistics, Standard deviations etc.
2.research.pdf consist my result, hypothesis, project description.
3. ProjectDetails.md which has the requirements to be fulfilled to complete this project.

Project Overview:
=================


In this project, I have investigated a  phenomenon from experimental psychology called the Stroop Effect.

I created a hypothesis regarding the outcome of the task, then I performed the task by myself and collected some data from others who have performed the same task and have computed some statistics describing the results. 

Finally, I have provided my results in terms of your hypotheses.
